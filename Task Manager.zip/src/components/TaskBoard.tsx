import React, { useEffect } from "react";
import TaskCard from "./TaskCard";
import { ScrollArea } from "./ui/scroll-area";
import { motion } from "framer-motion";

interface Task {
  id: string;
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  dueDate: string;
  assignee: {
    name: string;
    avatar: string;
  };
  aiInsights: string;
}

interface TaskBoardProps {
  tasks?: Task[];
  onTaskDragEnd?: (taskId: string, x: number, y: number) => void;
  onDeleteTask?: (taskId: string) => void;
}

const TaskBoard = ({
  tasks = [],
  onTaskDragEnd = (taskId, x, y) => console.log("Task moved:", { taskId, x, y }),
  onDeleteTask = (taskId) => console.log("Delete task:", taskId),
}: TaskBoardProps) => {
  console.log("TaskBoard received tasks:", tasks);
  
  return (
    <div className="w-full h-full bg-gray-50 p-6">
      <ScrollArea className="h-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {!tasks || tasks.length === 0 ? (
            <div className="col-span-full text-center text-gray-500 py-8">
              No tasks yet. Create your first task!
            </div>
          ) : (
            tasks.map((task) => {
              console.log("Rendering task:", task);
              if (!task || !task.id) {
                console.error("Invalid task data:", task);
                return null;
              }
              return (
                <motion.div
                  key={task.id}
                  drag
                  dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
                  dragElastic={0.1}
                  dragMomentum={false}
                  onDragEnd={(_, info) => {
                    onTaskDragEnd(task.id, info.point.x, info.point.y);
                  }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <TaskCard
                    title={task.title}
                    description={task.description}
                    priority={task.priority}
                    dueDate={task.dueDate}
                    assignee={task.assignee}
                    aiInsights={task.aiInsights}
                    onDelete={() => onDeleteTask(task.id)}
                  />
                </motion.div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default TaskBoard;
