import React, { useState, useEffect } from "react";
import { getTasks, createTask, deleteTask } from "../lib/tasks";
import { useAuth } from "./auth/AuthContext";
import Sidebar from "./Sidebar";
import TaskBoard from "./TaskBoard";
import TaskCreationDialog from "./TaskCreationDialog";
import FloatingActionButton from "./FloatingActionButton";
import CollaboratorsBar from "./CollaboratorsBar";

interface HomeProps {
  initialDarkMode?: boolean;
}

const Home = ({ initialDarkMode = false }: HomeProps) => {
  const [isDarkMode, setIsDarkMode] = useState(initialDarkMode);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeMenuItem, setActiveMenuItem] = useState("dashboard");
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [tasks, setTasks] = useState<any[]>([]);

  useEffect(() => {
    const loadTasks = async () => {
      try {
        const tasks = await getTasks();
        setTasks(tasks);
      } catch (error) {
        console.error("Error loading tasks:", error);
      }
    };
    loadTasks();
  }, []);

  const { signOut } = useAuth();

  const handleThemeToggle = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleTaskCreate = async (values: any) => {
    console.log("Creating task with values:", values);
    try {
      if (!values.title || !values.description) {
        alert("Title and description are required");
        return;
      }

      const dueDate = values.dueDate?.from 
        ? new Date(values.dueDate.from).toISOString()
        : new Date().toISOString();
      
      const assigneeName = values.assignees?.trim() || "Unassigned";
      const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(assigneeName)}`;
      
      const taskData = {
        title: values.title.trim(),
        description: values.description.trim(),
        priority: values.priority || "medium",
        due_date: dueDate,
        assignee_name: assigneeName,
        assignee_avatar: avatarUrl,
        ai_insights: "New task added to the system"
      };

      console.log("Sending task data to server:", taskData);
      const createdTask = await createTask(taskData);
      console.log("Response from server:", createdTask);
      
      if (createdTask) {
        console.log("Task created successfully, fetching updated tasks...");
        const updatedTasks = await getTasks();
        console.log("Updated tasks:", updatedTasks);
        setTasks(updatedTasks);
        setIsDialogOpen(false);
      }
    } catch (error: any) {
      console.error("Error creating task:", error);
      alert(error.message || "Failed to create task. Please try again.");
    }
  };

  const handleVoiceInput = () => {
    setIsVoiceListening(!isVoiceListening);
  };

  const handleMenuItemClick = (item: string) => {
    setActiveMenuItem(item);
    switch (item) {
      case "dashboard":
        break;
      case "calendar":
        console.log("Navigating to calendar");
        break;
      case "team":
        console.log("Navigating to team");
        break;
      case "settings":
        console.log("Navigating to settings");
        break;
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await deleteTask(taskId);
      setTasks(tasks.filter((task) => task.id !== taskId));
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  return (
    <div className={`flex h-screen bg-background ${isDarkMode ? "dark" : ""}`}>
      <Sidebar
        isDarkMode={isDarkMode}
        onThemeToggle={handleThemeToggle}
        activeItem={activeMenuItem}
        onMenuItemClick={handleMenuItemClick}
        isCollapsed={isSidebarCollapsed}
        onSignOut={signOut}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <CollaboratorsBar />

        <main className="flex-1 overflow-hidden">
          <TaskBoard tasks={tasks} onDeleteTask={handleDeleteTask} />
        </main>

        <TaskCreationDialog
          open={isDialogOpen}
          onOpenChange={setIsDialogOpen}
          onSubmit={handleTaskCreate}
          aiSuggestions={{
            description:
              "Consider breaking this task into smaller subtasks for better management.",
            estimatedTime: "3 hours",
            assignees: "Team Alpha",
          }}
        />

        <FloatingActionButton
          onVoiceClick={handleVoiceInput}
          onCreateClick={() => setIsDialogOpen(true)}
          isListening={isVoiceListening}
        />
      </div>
    </div>
  );
};

export default Home;
