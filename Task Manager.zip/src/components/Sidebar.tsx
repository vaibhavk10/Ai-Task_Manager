import React from "react";
import { Button } from "./ui/button";
import {
  LayoutDashboard,
  Calendar,
  Users,
  Settings,
  Sun,
  Moon,
  Menu,
  LogOut,
} from "lucide-react";
import { cn } from "../lib/utils";
import { Separator } from "./ui/separator";

interface SidebarProps {
  className?: string;
  isDarkMode?: boolean;
  onThemeToggle?: () => void;
  activeItem?: string;
  onMenuItemClick?: (item: string) => void;
  isCollapsed?: boolean;
  onSignOut?: () => void;
}

const Sidebar = ({
  className = "",
  isDarkMode = false,
  onThemeToggle = () => {},
  activeItem = "dashboard",
  onMenuItemClick = (item: string) => console.log("Menu item clicked:", item),
  isCollapsed = false,
  onSignOut = () => console.log("Sign out clicked"),
}: SidebarProps) => {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "team", label: "Team", icon: Users },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div
      className={cn(
        "flex flex-col h-full bg-background border-r p-4 transition-all duration-300",
        isCollapsed ? "w-[70px]" : "w-[280px]",
        className,
      )}
    >
      <div className="flex items-center justify-between mb-6">
        {!isCollapsed && <h2 className="text-xl font-bold">Task Manager</h2>}
        <Button
          variant="ghost"
          size="icon"
          className="ml-auto"
          onClick={onThemeToggle}
        >
          {isDarkMode ? (
            <Sun className="h-5 w-5" />
          ) : (
            <Moon className="h-5 w-5" />
          )}
        </Button>
      </div>

      <Separator className="mb-4" />

      <nav className="space-y-2 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeItem === item.id ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                isCollapsed ? "px-2" : "px-4",
              )}
              onClick={() => onMenuItemClick(item.id)}
            >
              <Icon className="h-5 w-5" />
              {!isCollapsed && <span className="ml-2">{item.label}</span>}
            </Button>
          );
        })}
      </nav>

      <Separator className="my-4" />

      <div className="mt-auto space-y-2">
        <Button
          variant="ghost"
          size="icon"
          className="w-full justify-start"
          onClick={() => {}}
        >
          <Menu className="h-5 w-5" />
          {!isCollapsed && <span className="ml-2">Collapse</span>}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
          onClick={onSignOut}
        >
          <LogOut className="h-5 w-5" />
          {!isCollapsed && <span className="ml-2">Sign Out</span>}
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
