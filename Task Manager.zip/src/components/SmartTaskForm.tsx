import React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "./ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./ui/form";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { CalendarIcon, Clock, Users } from "lucide-react";
import DatePickerWithRange from "./ui/date-picker-with-range";

const formSchema = z.object({
  title: z.string().min(2, "Title must be at least 2 characters").max(50, "Title must be less than 50 characters"),
  description: z.string().min(2, "Description must be at least 2 characters").max(500, "Description must be less than 500 characters"),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueDate: z
    .object({
      from: z.date(),
      to: z.date().optional(),
    })
    .optional()
    .transform((date) => {
      if (!date) return undefined;
      return {
        from: date.from,
        to: date.to || date.from,
      };
    }),
  estimatedTime: z.string().optional(),
  assignees: z.string().optional(),
});

interface SmartTaskFormProps {
  onSubmit?: (values: z.infer<typeof formSchema>) => void;
  aiSuggestions?: {
    description?: string;
    estimatedTime?: string;
    assignees?: string;
  };
}

const SmartTaskForm = ({
  onSubmit = (values) => console.log(values),
  aiSuggestions = {
    description:
      "This task involves implementing the new feature as discussed in the planning meeting.",
    estimatedTime: "4 hours",
    assignees: "John Doe, Jane Smith",
  },
}: SmartTaskFormProps) => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: "medium",
      dueDate: {
        from: new Date(),
        to: new Date(),
      },
      estimatedTime: "",
      assignees: "",
    },
  });

  return (
    <div className="w-full bg-background">
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit((data) => {
            if (!data.title || !data.description) {
              return;
            }
            console.log("Submitting form data:", data);
            onSubmit(data);
          })}
          className="flex flex-col gap-6"
        >
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="required">Task Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter task title" {...field} required />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="required">Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter task description"
                    className="min-h-[100px] resize-none"
                    {...field}
                    required
                  />
                </FormControl>
                {aiSuggestions.description && (
                  <Card className="p-3 mt-2 bg-muted">
                    <p className="text-sm">AI Suggestion:</p>
                    <p className="text-sm text-muted-foreground">
                      {aiSuggestions.description}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="mt-2"
                      type="button"
                      onClick={() =>
                        form.setValue(
                          "description",
                          aiSuggestions.description || "",
                          { shouldValidate: true }
                        )
                      }
                    >
                      Use Suggestion
                    </Button>
                  </Card>
                )}
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="priority"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Priority</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="low">
                        <Badge
                          variant="secondary"
                          className="bg-green-100 text-green-800"
                        >
                          Low
                        </Badge>
                      </SelectItem>
                      <SelectItem value="medium">
                        <Badge
                          variant="secondary"
                          className="bg-yellow-100 text-yellow-800"
                        >
                          Medium
                        </Badge>
                      </SelectItem>
                      <SelectItem value="high">
                        <Badge
                          variant="secondary"
                          className="bg-red-100 text-red-800"
                        >
                          High
                        </Badge>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Due Date Range</FormLabel>
                  <FormControl>
                    <DatePickerWithRange
                      date={field.value}
                      setDate={field.onChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="estimatedTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Estimated Time</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input {...field} placeholder="e.g. 4 hours" />
                      <Clock className="absolute right-3 top-2.5 h-5 w-5 text-muted-foreground" />
                    </div>
                  </FormControl>
                  {aiSuggestions.estimatedTime && (
                    <FormDescription>
                      AI suggests: {aiSuggestions.estimatedTime}
                    </FormDescription>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="assignees"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assignees</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input {...field} placeholder="Enter assignees" />
                      <Users className="absolute right-3 top-2.5 h-5 w-5 text-muted-foreground" />
                    </div>
                  </FormControl>
                  {aiSuggestions.assignees && (
                    <FormDescription>
                      AI suggests: {aiSuggestions.assignees}
                    </FormDescription>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full mt-4"
            disabled={!form.formState.isValid || form.formState.isSubmitting}
          >
            {form.formState.isSubmitting ? "Creating..." : "Create Task"}
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default SmartTaskForm;
